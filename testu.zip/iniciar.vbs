Set WshShell = CreateObject("WScript.Shell")

' Detecta la carpeta base del usuario actual (ej. C:\Users\TuUsuario)
userProfile = WshShell.ExpandEnvironmentStrings("%USERPROFILE%")

' Arma la ruta absoluta completa asegurando que soporte espacios
rutaKeePass = """" & userProfile & "\AppData\Local\Microsoft\Vault\KeePass.exe"" -minimize"

' Ejecuta el programa de forma oculta (0) sin esperar respuesta (False)
WshShell.Run rutaKeePass, 0, False