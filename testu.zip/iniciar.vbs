Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """%LOCALAPPDATA%\Microsoft\Vault\KeePass.exe""", 0, False