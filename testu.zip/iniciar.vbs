Set WshShell = CreateObject("WScript.Shell")
' Expandimos la variable de entorno para obtener la ruta base del usuario actual (ej. C:\Users\TuUsuario)
userProfile = WshShell.ExpandEnvironmentStrings("%USERPROFILE%")

' Construimos la ruta dinámica con las comillas necesarias para los espacios
rutaKeePass = """" & userProfile & "\AppData\Local\Microsoft\Vault\KeePass.exe"" -minimize"

' Ejecutamos
WshShell.Run rutaKeePass, 0, False