Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "KeePass.exe -minimize", 0, False